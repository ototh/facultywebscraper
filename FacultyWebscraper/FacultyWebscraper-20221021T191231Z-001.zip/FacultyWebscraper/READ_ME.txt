Warning the application does not currently work on Apple products

Make sure your Google Chrome application is on version 106.
This is the current version of Google Chrome

Run FacultyWebScraper.exe

Windows will give a warning about the application not being safe.
To get past this please select "More info" then "Run anyways".

Then your windows terminal will open and should display information about what is happening.
The scraped data will then be printed to the console.
